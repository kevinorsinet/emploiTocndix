//>>built
define("dijit/nls/bg/loading",({loadingState:"Зареждане...",errorState:"Съжаляваме, възникна грешка"}));
