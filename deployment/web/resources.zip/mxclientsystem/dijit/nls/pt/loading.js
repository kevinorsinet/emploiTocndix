//>>built
define("dijit/nls/pt/loading",({loadingState:"Carregando...",errorState:"Desculpe, ocorreu um erro"}));
