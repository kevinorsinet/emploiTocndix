//>>built
define("dijit/nls/it/common",({buttonOk:"Ok",buttonCancel:"Annulla",buttonSave:"Salva",itemClose:"Chiudi"}));
