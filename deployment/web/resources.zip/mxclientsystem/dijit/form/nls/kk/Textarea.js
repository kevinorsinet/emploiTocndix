//>>built
define("dijit/form/nls/kk/Textarea",({iframeEditTitle:"өңдеу аумағы",iframeFocusTitle:"өңдеу аумағының жақтауы"}));
